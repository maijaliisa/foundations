#Maija Ehlinger
#May 24, 2017
#Homework 2, Part 2 

#PART TWO: LISTS 
countries = ["Finland", "Turkey", "USA", "Argentina", "Japan", "France", "Germany"]

#CREATE A FOR LOOP 
print ("2.")
for places in countries:
  print(places)
#sort the list permanently, do sorted(name of the list) and then a for loop 
print ("3.")
for places in sorted(countries):
  print (places)
#display the first element in a list 
print("4.")
print(countries[0])
#Display the second-to-last element of the list.
print("5.")
print(countries[5])
#Delete one of the countries from the list using its name. I created a new list so that I could delete one of the values 
countries2 = ["Finland", "Turkey", "USA", "Argentina", "Japan", "France", "Germany"]
print ("6")
countries2.remove("USA")
for new_places in countries2:
  print(new_places)
#Using a for loop, print each country's name in all caps
print("7.")
for new_places in countries2:
  print(new_places.upper())

#PART TWO: Dictionaries
#1) Make a dictionary called 'tree' that responds to 'name', 'species', 'age', 'location_name', 'latitude' and 'longitude'. Pick a tree from: https://en.wikipedia.org/wiki/List_of_trees

tree = {
  'name': 'Lone Cypress',
  'species': 'Cypress',
  'age': 250,
  'location_name': 'Pebble Beach, California',
  'latitude': 36.572529,
  'longitude': -121.948594

}

# 2.Print the sentence "{name} is a {years} year old tree that is in {location_name}"
print("2.")
print(tree['name'], "is a", tree ['age'], "year old tree in", tree['location_name'],".")
print("The tree", tree['name'], "in", tree['location_name'], "is south of NYC.")
#4) Ask the user how old they are. If they are older than the tree, display "you are {XXX} years older than {name}." If they are younger than the tree, display "{name} was {XXX} years old when you were born."

age=input("4. How old are you?")
age_difference = 250 - int(age)
if int(age) < 250:
  print(tree['name'],"was", age_difference, "years old when you were born.")
else:
  print("Are you really over 251 yearss old?")

#PART TWO: Lists of dictionaries

cities = [

{
  'name': 'Moscow',
  'latitude': 55.755826,
  'longitude': 37.617300
},

{
  'name': 'Tehran',
  'latitude': 35.689197,
  'longitude': 51.388974
},

{
  'name': 'Falkland Islands',
  'latitude': -51.796253,
  'longitude': -59.523613
},

{
  'name': 'Seoul',
  'latitude': 37.566535,
  'longitude': 126.977969
},

{
  'name': 'Santiago',
  'latitude': -33.448890,
  'longitude': -70.669265
}

]

for city in cities:
  print(city['name'])
  #if city['name'] = city['Falkland Island']:
    #print("The Falkland Islands are a biogeographical part of the mild Antarctic zone")
  if city['latitude'] > 0:
    print("It is above the equator")
  if city['latitude'] <=0:
    print("It is below the equator")
  if city['latitude'] > 36.572529:
    print("It is above the latitude of",tree['name'])
  else:
    print("It is below the latitude of",tree['name'])


#print(cities[0])
#print(city_latitude.keys())
#print(city_latitude.values())



